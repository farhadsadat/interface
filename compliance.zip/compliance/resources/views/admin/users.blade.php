@extends('admin.layout.auth')

@section('content')
<center><h6>Users ADMIN</h6></center>
<hr>

<div class="container">
    <div class="row">
        <div class="col-md-12 col-md-offset-2">
        
        <a class="btn btn-primary" href="{{ url('/admin/register') }}" target="_blank">Register</a>    
       	<!--  <a class="btn btn-primary" onclick="location.href='{{ url('/admin/register') }}'">Register</a>	 -->	
            <table id="example" class="table table-striped table-bordered" cellspacing="0" width="100%">
           <thead>
            <tr style="background-color: #1f4a91; color: white;" >
            
                <th>ID</th>
                <th>User Name</th>
                <th>Email</th>
                <th>Password</th>
                <th>Register</th>
                <th>Edit</th>
                <th>Delete</th>
            </tr>
        </thead>
        
        <tbody>
        @foreach($ausers as $key => $auser)
        <tr >
            
            <td>{{ $auser->id}}</td>
            <td>{{ $auser->name }}</td>
            <td>{{ $auser->email}}</td>
            <td>{{ $auser->password}}</td>
            <td><a class="btn btn-primary" href="{{ url('/admin/register') }}" target="_blank">Register</a></td>
            
             <td><a class="btn btn-primary" href="{{ route('editit',$auser->id) }}">Edit</a></td>
            <td>
            	 {!! Form::open(['method' => 'DELETE','route' => ['destroyit', $auser->id],'style'=>'display:inline']) !!}
            {!! Form::submit('Delete', ['class' => 'btn btn-danger']) !!}
            {!! Form::close() !!}
            </td>

        </tr>
        @endforeach
        </tbody>     
    </table> 
        
        </div>

    </div>
</div>
<br>
<br>

<center><h6>Users Empolyee</h6></center>
<hr>

<div class="container">
    <div class="row">
        <div class="col-md-12 col-md-offset-2">
           <a class="btn btn-primary" href="{{ url('/employee/register') }}" target="_blank">Register</a> 

            <table id="example" class="table table-striped table-bordered" cellspacing="0" width="100%">
           <thead>
            <tr style="background-color: #1f4a91; color: white;" >
            
                <th>ID</th>
                <th>User Name</th>
                <th>Email</th>
                <th>Password</th>
                <th>Register</th>
                <th>Edit</th>
                <th>Delete</th>
            </tr>
        </thead>
        
        <tbody>
        @foreach($eusers as $key => $euser)
        <tr >
            
            <td>{{ $euser->id}}</td>
            <td>{{ $euser->name }}</td>
            <td>{{ $euser->email}}</td>
            <td>{{ $euser->password}}</td>
            <td><a class="btn btn-primary" href="{{ url('/employee/register') }}" target="_blank">Register</a></td>
            <td><a class="btn btn-primary" href="{{ route('editem',$euser->id) }}">Edit</a></td>
            <td>
            	 {!! Form::open(['method' => 'DELETE','route' => ['destroyem', $euser->id],'style'=>'display:inline']) !!}
            {!! Form::submit('Delete', ['class' => 'btn btn-danger']) !!}
            {!! Form::close() !!}
            </td>

            
             
            

        </tr>
        @endforeach
        </tbody>     
    </table> 
        
        </div>

    </div>
</div>

@endsection