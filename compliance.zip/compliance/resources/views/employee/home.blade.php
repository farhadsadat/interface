@extends('employee.layout.auth')

@section('content')

<div class="container">
    <div class="row">
        <div class="col-md-12 col-md-offset-2">
            <div class="panel panel-default">
                

                <center>
                    <div>
                                    <a href="{{ url('/employee/logout') }}"
                                        onclick="event.preventDefault();
                                                 document.getElementById('logout-form').submit();">
                                        Logout
                                    </a>

                                    <form id="logout-form" action="{{ url('/employee/logout') }}" method="POST" style="display: none;">
                                        {{ csrf_field() }}
                                    </form>
                    </div>
                </center>

                <div style="text-align: center;" class="panel-body">
                    <h6>You are logged in as {{ Auth::user()->name }}</h6>
                    
                   </br> 
                   </br> 
                    <div class="container">
                        <div class="row">
                            <div class="col-md-12">
                                 <div class="card" >
                                      <center><img class="card-img-top" src="../public/img/logo.png"  ></center>
                                      <br>
                                      <div class="card-block">
                                       <center><h4 class="card-title">Compliance Interface</h4></center>
                                        <h6 class="card-text" style="text-align: center;">PSU Follow-up Form</h6>
                                      </div>
                                      
                                      <center>
                                          <div class="card-block">
                                            <div class="btn-group-md" role="group" aria-label="Basic example">
                                              <button style="background-color: green; color: white;" type="button" class="btn btn-secondary" onclick="location.href='{{ url('/employee/complete') }}'">View Complete</button>
                                              <button style="background-color: green; color: white;" type="button" class="btn btn-secondary" onclick="location.href='{{ url('/employee/table') }}'"> View Incomplete</button>

                                              <button style="background-color: green; color: white;" type="button" class="btn btn-secondary" onclick="location.href='{{ url('/employee/table/create') }}'">Create</button>
                                              
                                            </div>
                                          </div>
                                      </center>
                                </div>           
                            </div>
                        </div>
                    </div>

                    

                </div>
            </div>
        </div>
    </div>
</div>

<div class="container">
    <div class="row">
        <div class="col-md-12 col-md-offset-2">

        </div>
    </div>
</div>


@endsection


