@extends('layouts.master')

@section('content')

<form method="GET">
	
    fileup#<input type="text" name="fileupno"></br>
    branch name<input type="text" name="branchname">
    
</form>

 <!-- <div class="container"> -->
    <div class="row">
        <div class="col-sm-12 ">
            <table id="example" class="table table-striped table-bordered" cellspacing="0" width="100%">
           <thead>
            <tr style="background-color: #019e4d; color: white; font-size: 11px; font-family: 'Roboto', sans-serif;" >
            
                <th>S.NO</th>
                <th>Date</th>
                <th>FileUp No.</th>
                <th>Branch Name</th>
                <th>Customer Name</th>
                <th>Account Number</th>
                <th>Beneficiary Name</th>
                <th>Goods</th>
                <th>Invoice</th>
                <th>Amount</th>
                <th>Currency</th>
                <th>Country</th>
                <th>ACCD Received</th>
                <th>Shiping Document Received</th>
                <th>Promisery Letter Received</th>
                <th>Sales Contract Received</th>
                <th>Lease Agreement Received</th>
                
                <th>Due Date</th>
                <th>Extended</th>
                <th>Extended Due Date</th>
                <th>Comments</th>
                <th>Final Status</th>
                <th>Incomplete Document Fileup#</th>
            </tr>
        </thead>
        

        
        <tbody>
        @foreach($result as $key => $ho)
        <tr style=" font-family: 'Roboto', sans-serif;">
            
            <td>{{ $ho->id}}</td>
           <td>
              <?php

              $startTime = $ho->sdate;
              $startTime = strtotime($startTime);
              echo date('M-d-Y', $startTime);;           
?>
            </td>
            <td>{{ $ho->fileupno }}</td>
            <td>{{ $ho->branchname }}</td>
            <td>{{ $ho->cname }}</td>
            <td>{{ $ho->acno }}</td>
            <td>{{ $ho->benname }}</td>
            <td>{{ $ho->goods }}</td>
            <td>{{ $ho->invoice }}</td>
            <td>{{ $ho->amount }}</td>
            <td>{{ $ho->currency }}</td>
            <td>{{ $ho->country }}</td>
            <td>{{ $ho->accdrec }}</td>
            <td>{{ $ho->shdocrec }}</td>
            <td>{{ $ho->pletterr }}</td>
            <td>{{ $ho->scontactr }}</td>
            <td>{{ $ho->largr }}</td>
            
            <td style="background-color: red; color: white;">
              <?php

              $startTime = $ho->duedate;
              $startTime = strtotime($startTime);
              echo date('M-d-Y', $startTime);
              ?>
            </td>

            <td style="background-color: grey; color: white;">{{ $ho->extduedate }}</td>
             <td>{{ $ho->extenddatedate }}</td>
            
           
            <td>{{ $ho->extreason }}</td>
            <td>{{ $ho->complete }}</td>
            <td>{{ $ho->incocomment }}</td>
         
        </tr>

        @endforeach
        </tbody>
       


             </table> 

             

        </div>
    </div>
<!-- </div> -->

@endsection

<form action="/search" method="POST" role="search">
	{{ csrf_field() }}
	<div class="input-group">
		<input type="text" name="q" class="form-control" placeholder="search fileupno"> 
		<span class="input-group-btn">
			<button type="submit" class="btn btn-default">
			<span class="glyphicon glyphicon-search"></span>	
			</button>
		</span>
	</div>
</form>