<?php $__env->startSection('content'); ?>

  <div class="container">
                        <div class="row">
                            <div class="col-md-12">

                                <center>
   <div class="card" style="width: 30rem; ">
                                      <center><img class="card-img-top" src="../public/img/logo.png"   ></center>
                                     
                                      <div class="card-block">
                                      
                                        <center><h4 class="card-title">Compliance Interface</h4></center>
                                        <h6 class="card-text" style="text-align: center;">PSU Follow-up Form</h6>
                                        
                                      </div>
                                      <center>
                                          <div class="card-block">
                                            <div class="btn-group-md" role="group" aria-label="Basic example">
                                              <button style="background-color: green; color: white;" type="button" class="btn btn-secondary" onclick="location.href='<?php echo e(url('/admin/complete')); ?>'"> View Complete</button>
                                             

                                              <button style="background-color: green; color: white;" type="button" class="btn btn-secondary" onclick="location.href='<?php echo e(url('/admin/table/create')); ?>'">Create</button>
                                              <a class="btn btn-primary" href="<?php echo e(route('admin.home')); ?>"> Back</a>
                                            </div>
                                          </div>
                                      </center>
                                      
                                      
    </div>
    </center>

          
                            </div>
                        </div>
                    </div>

<br>
<br>

<div class="container">
    <div class="row">
        <div class="col-sm-12 ">
            <table id="example" class="table table-striped table-bordered" cellspacing="0" width="100%">
           <thead>
            <tr style="background-color: #019e4d; color: white;font-size: 11px;  font-family: 'Roboto', sans-serif;" >
            
                <th>S.NO</th>
                <th>Username</th>
                <th>Date</th>
                <th>FileUp No.</th>
                <th>Branch Name</th>
                <th>Customer Name</th>
                <th>Account Number</th>
                <th>Beneficiary Name</th>
                <th>Goods</th>
                <th>Invoice</th>
                <th>Amount</th>
                <th>Currency</th>
                <th>Country</th>
                <th>ACCD Received</th>
                <th>Shiping Document Received</th>
                <th>Promisery Letter Received</th>
                <th>Sales Contract Received</th>
                <th>Lease Agreement Received</th>  
                <th>Due Date</th>
                <th>Extended</th>
                <th>Extended Due Date</th>
                <th>Comments</th>
                <th>Final Status</th>
                <th>Incomplete Document Fileup#</th>
                
                <th>Edit</th>
                <th>Delete</th>
            </tr>
        </thead>
        
        <tbody>
        <?php $__currentLoopData = $items; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $ho): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <tr style=" font-family: 'Roboto', sans-serif;">
            
           <td><?php echo e($ho->id); ?></td>
           <td><?php echo e($ho->employees_name); ?></td>
            <td><?php echo e($ho->sdate); ?></td>
            <td><?php echo e($ho->fileupno); ?></td>
            <td><?php echo e($ho->branchname); ?></td>
            <td><?php echo e($ho->cname); ?></td>
            <td><?php echo e($ho->acno); ?></td>
            <td><?php echo e($ho->benname); ?></td>
            <td><?php echo e($ho->goods); ?></td>
             <td><?php echo e($ho->invoice); ?></td>
            <td><?php echo e($ho->amount); ?></td>
            <td><?php echo e($ho->currency); ?></td>
            <td><?php echo e($ho->country); ?></td>
            <td><?php echo e($ho->accdrec); ?></td>
            <td><?php echo e($ho->shdocrec); ?></td>
            <td><?php echo e($ho->pletterr); ?></td>
            <td><?php echo e($ho->scontactr); ?></td>
            <td><?php echo e($ho->largr); ?></td>
            
             <td style="color: white; background-color:red; "><?php echo e($ho->duedate); ?></td>
            <td style="background-color: grey; color: white;"><?php echo e($ho->extduedate); ?></td>
             <td><?php echo e($ho->extenddatedate); ?></td>
            <td><?php echo e($ho->extreason); ?></td>
            <td><?php echo e($ho->complete); ?></td>
            <td><?php echo e($ho->incocomment); ?></td>
            
            <td><a class="btn btn-primary" href="<?php echo e(route('table.edit',$ho->id)); ?>">Edit</a></td>

            <td>
               <?php echo Form::open(['method' => 'DELETE','route' => ['table.destroy', $ho->id],'style'=>'display:inline']); ?>

            <?php echo Form::submit('Delete', ['class' => 'btn btn-danger']); ?>

            <?php echo Form::close(); ?>

            </td>
             
             
            

        </tr>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </tbody>     
    </table> 
        
     </div>
    </div>
</div>
         

      
<?php $__env->stopSection(); ?>
 
<?php echo $__env->make('admin.layout.auth', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>