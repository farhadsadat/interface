<!DOCTYPE html>
<html>
<head>
	<title>Compliance Interface</title>

	  <meta charset="utf-8">
        <meta http-equiv="X-UA-Compatible" content="IE=edge">
        <meta name="viewport" content="width=device-width, initial-scale=1">

        <meta name="csrf-token" content="<?php echo e(csrf_token()); ?>">

        
            <!-- Materializecss compiled and minified CSS -->
         

         <!--Import Google Icon Font-->
        <!--  <link href="<?php echo e(asset('https://maxcdn.bootstrapcdn.com/bootstrap/4.0.0-alpha.6/css/bootstrap.min.css')); ?>" integrity="sha384-rwoIResjU2yc3z8GV/NPeZWAv56rSmLldC3R/AZzGRnGxQQKnKkoFVhFQhNUwEyJ" crossorigin="anonymous" rel="stylesheet">
 -->
         <link href="http://10.1.254.198/complianceTest/public/bootstrap/css/bootstrap.min.css" rel="stylesheet">


         <!-- Styles -->
    <link href="/css/app.css" rel="stylesheet">
   
    

    <link rel="stylesheet" type="text/css" href="http://10.1.254.198/complianceTest/public/datatable/DataTables/css/dataTables.bootstrap.min.css">
    <link rel="stylesheet" type="text/css" href="http://10.1.254.198/complianceTest/public/datatable/Buttons/css/buttons.bootstrap.css">
    <link rel="stylesheet" type="text/css" href="http://10.1.254.198/complianceTest/public/datatable/Buttons/css/buttons.bootstrap.min.css">
    <link rel="stylesheet" type="text/css" href="http://10.1.254.198/complianceTest/public/datatable/Buttons/css/buttons.dataTables.css">
    <link rel="stylesheet" type="text/css" href="http://10.1.254.198/complianceTest/public/datatable/Buttons/css/buttons.dataTables.min.css">
     <link rel="stylesheet" type="text/css" href="http://10.1.254.198/complianceTest/public/datatable/DataTables/css/jquery.dataTables.min.css">
      <link rel="stylesheet" type="text/css" href="http://10.1.254.198/complianceTest/public/datatable/Buttons/css/buttons.dataTables.min.css">
    <!-- <link rel="stylesheet" type="text/css" href="https://cdn.datatables.net/1.10.15/css/dataTables.bootstrap.min.css"> -->

    <!-- <link rel="stylesheet" type="text/css" href="//cdn.datatables.net/buttons/1.0.0/css/buttons.bootstrap.css">
    <link rel="stylesheet" type="text/css" href="//cdn.datatables.net/buttons/1.0.0/css/buttons.bootstrap.min.css"> -->
    
    <!-- <link rel="stylesheet" type="text/css" href="//cdn.datatables.net/buttons/1.0.0/css/buttons.dataTables.css">
    <link rel="stylesheet" type="text/css" href="//cdn.datatables.net/buttons/1.0.0/css/buttons.dataTables.min.css">
    <link href="https://cdn.datatables.net/1.10.15/css/jquery.dataTables.min.css" rel="stylesheet">
    <link href="https://cdn.datatables.net/buttons/1.4.0/css/buttons.dataTables.min.css"> -->


        <style type="text/css">
            footer{
  color: white;
}
footer a{
  color: white;
}
footer a:hover{
  color: white;
}

.footer-bottom{
  background: #010e19;

  padding: 2em;
}
.footer-top{
  background: #2d4958;  
}
.footer-middle{
   background: #1f4a91;
  padding-top: 2em;
  color: white;
}
/**Sub Navigation**/
.subnavigation-container{
  background: #3d6277;
}
.subnavigation .nav-link{
  color: white;
  font-weight: bold;
}
.subnavigation-container{
  text-align: center;
}
.subnavigation-container .navbar{
  display: inline-block;
  margin-bottom: -6px; /* Inline-block margin offffset HACK -Gilron */
}
.col-subnav a{
  padding: 1rem 1rem;
  color: white;
  font-weight: bold;
}
.col-subnav .active{
  border-top:5px solid orange;
 background: white;
  color: black;
}
        </style>

         <!--Import Materialize-Stepper CSS (after importing materialize.css) -->
        
        
         
</head>
<body>

	<!-- Navbar -->
    <header>
      <!-- Image and text -->

      <!-- <nav class="navbar navbar-light" style="background-color: #e3f2fd;">
    
    </nav> -->
<nav class="navbar navbar-toggleable-md" style="background-color: #1f4a91;">
  <button class="navbar-toggler navbar-toggler-right" type="button" data-toggle="collapse" data-target="#navbarSupportedContent" aria-controls="navbarSupportedContent" aria-expanded="false" aria-label="Toggle navigation">
    <span class="navbar-toggler-icon"></span>
  </button>
  <a class="navbar-brand" href="#" style="color: white;">AIB</a>

  <div class="collapse navbar-collapse" id="navbarSupportedContent">
    <ul class="navbar-nav mr-auto">
      <li class="nav-item active">
        <a class="nav-link" href="#" style="color: white;">Home <span class="sr-only">(current)</span></a>
      </li>
     
      
    </ul>
    
  </div>
</nav>

  <br>


 
<br>
    </header>
    <!-- End of Navbar --> 


	<div class="container">

   <center>
   <div class="card" style="width: 30rem; ">
                                      <center><img class="card-img-top" src="public/img/logo.png"   ></center>
                                     
                                      <div class="card-block">
                                      
                                        <center><h4 class="card-title">Compliance Interface</h4></center>
                                        <h6 class="card-text" style="text-align: center;">PSU Follow-up Form</h6>
                                        <center>
                                          <div class="card-block">
                                            <div class="btn-group-md" role="group" aria-label="Basic example">
                                              <button style="background-color: green; color: white;" type="button" class="btn btn-secondary" onclick="location.href='<?php echo e(url('/complete')); ?>'"> View Complete</button>
                                             

                                              <button style="background-color: green; color: white;" type="button" class="btn btn-secondary" onclick="location.href='<?php echo e(url('/')); ?>'">View Incomplete</button>
                                              
                                            </div>
                                          </div>
                                      </center>
                                      
                                      </div>
                                      
                                      
    </div>
    </center>

<br>
            <?php echo $__env->yieldContent('content'); ?>
        </div>
<br>
   <footer>
   

<div class="m-t-3"></div>

<footer class="mainfooter" role="contentinfo">
  <div class="footer-top p-y-2">
    <div class="container-fluid">
      
    </div>
  </div>
  <div class="footer-middle">
  <div class="container">
    <div class="row">
      <div class="col-md-3 col-sm-6">
        <!--Column1-->
        <div class="footer-pad">
          <h4>Address</h4>
          <address>
    Shahr-e-Naw, Haji Yaqoob Square,
    Shahabudin Watt, P.O.Box No. 207,
    Kabul Afghanistan
                            </address>
        </div>
      </div>
      <div class="col-md-3 col-sm-6">
       
      </div>
      <div class="col-md-3 col-sm-6">
        <!--Column1-->
        <div class="footer-pad">
          <h4>Website Information</h4>
          <ul class="list-unstyled">
            <li><a href="aib.af">Afghanistan International bank</a></li>
            <li><a href="aib.af">Islamic Banking</a></li>
            <li><a href="aib.af">Online Banking</a></li>
           
          </ul>
        </div>
      </div>
      <div class="col-md-3 col-sm-6">
       
      </div>
    </div>
  </div>
  </div>
  <div class="footer-bottom">
    <div class="container">
      <div class="row">
        <div class="col-xs-12">
          <!--Footer Bottom-->
          <p class="text-xs-center">&copy; Copyright 2017 - Afghanistan Internation Bank.  All rights reserved.</p>
        </div>
      </div>
    </div>
  </div>
</footer>
   </footer>
     
</body>


<!-- ----------  jQuery ----------- -->

  
    <script src="public/js/jquery-1.12.4.js"></script>


    <script src="http://10.1.254.198/complianceTest/public/datatable/DataTables/js/jquery.dataTables.min.js"></script>
    <script src="http://10.1.254.198/complianceTest/public/datatable/DataTables/js/dataTables.bootstrap.min.js"></script>
    <script src="http://10.1.254.198/complianceTest/public/datatable/Buttons/js/dataTables.buttons.js"></script>
     <script src="http://10.1.254.198/complianceTest/public/datatable/Buttons/js/dataTables.buttons.min.js"></script>
     <script src="http://10.1.254.198/complianceTest/public/datatable/Buttons/js/buttons.colVis.min.js"></script>
      <script src="http://10.1.254.198/complianceTest/public/datatable/Buttons/js/buttons.flash.js"></script>
      <script src="http://10.1.254.198/complianceTest/public/datatable/Buttons/js/buttons.html5.js"></script>
      <script src="http://10.1.254.198/complianceTest/public/datatable/Buttons/js/buttons.html5.min.js"></script>
      <script src="http://10.1.254.198/complianceTest/public/datatable/Buttons/js/buttons.print.min.js"></script>

   
    <!-- <script src="//code.jquery.com/jquery-1.12.4.js"></script> -->
     
      <script src="http://10.1.254.198/complianceTest/public/js/bootstrap-datepicker.js"></script> 



    <!-- <script src="https://cdn.datatables.net/1.10.15/js/jquery.dataTables.min.js"></script>

     <script src="https://cdn.datatables.net/1.10.15/js/dataTables.bootstrap.min.js"></script> -->
    
    <!-- <script type="text/javascript" src="//cdn.datatables.net/buttons/1.0.0/js/dataTables.buttons.js"></script>

    <script type="text/javascript" src="//cdn.datatables.net/buttons/1.0.0/js/dataTables.buttons.min.js"></script> -->
    

    
    
   
    <!-- <script src="//cdn.rawgit.com/bpampuch/pdfmake/0.1.27/build/pdfmake.min.js"></script>
    <script type="text/javascript" src="//cdn.rawgit.com/bpampuch/pdfmake/0.1.27/build/vfs_fonts.js"></script> -->
  <!--   <script src="//cdn.datatables.net/buttons/1.4.0/js/buttons.print.min.js"></script> -->
    <!-- <script src="//cdn.datatables.net/buttons/1.4.0/js/buttons.colVis.min.js"></script> -->
   <!--  <script type="text/javascript" src="//cdn.datatables.net/buttons/1.0.0/js/buttons.flash.js"></script>
    
    
    <script type="text/javascript" src="//cdn.datatables.net/buttons/1.0.0/js/buttons.html5.js"></script>

    <script type="text/javascript" src="//cdn.datatables.net/buttons/1.0.0/js/buttons.html5.min.js"></script> -->




       <script type="text/javascript">
    $(document).ready(function() {
    $('#example').DataTable( {
      
        dom: 'Bfrtip',
        buttons: [
            'colvis', 'csv', 'excel'
        ],
        'lengthMenu': [[10, 25, 50, -1], [10, 25, 50, 'All']],
        'iDisplayLength': 250
    } );
} );
</script> 

   
    


</html>




