
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1">

    <!-- CSRF Token -->
    <meta name="csrf-token" content="<?php echo e(csrf_token()); ?>">

    <title><?php echo e(config('app.name', 'Compliance Interface')); ?></title>
  <link rel="stylesheet" href="http://192.168.0.14:8080/compliance/public/js/jquery-ui.css">
   

     <link href="http://192.168.0.14:8080/compliance/public/bootstrap/css/bootstrap.min.css" rel="stylesheet">
    <link rel="stylesheet" type="text/css" href="http://192.168.0.14:8080/compliance/public/datatable/DataTables/css/dataTables.bootstrap.min.css">
    <link rel="stylesheet" type="text/css" href="http://192.168.0.14:8080/compliance/public/datatable/Buttons/css/buttons.bootstrap.css">
    <link rel="stylesheet" type="text/css" href="http://192.168.0.14:8080/compliance/public/datatable/Buttons/css/buttons.bootstrap.min.css">
    <link rel="stylesheet" type="text/css" href="http://192.168.0.14:8080/compliance/public/datatable/Buttons/css/buttons.dataTables.css">
    <link rel="stylesheet" type="text/css" href="http://192.168.0.14:8080/compliance/public/datatable/Buttons/css/buttons.dataTables.min.css">
     <link rel="stylesheet" type="text/css" href="http://192.168.0.14:8080/compliance/public/datatable/DataTables/css/jquery.dataTables.min.css">
      <link rel="stylesheet" type="text/css" href="http://192.168.0.14:8080/compliance/public/datatable/Buttons/css/buttons.dataTables.min.css">


    <!-- Scripts -->
    <script>
        window.Laravel = <?php echo json_encode([
            'csrfToken' => csrf_token(),
        ]); ?>
    </script>
</head>
<body>
    <nav class="navbar navbar-default navbar-static-top" >
        <div class="container">
              <center>
            <div class="navbar-header" >

   
                <!-- Branding Image -->
                <a class="navbar-brand" href="<?php echo e(url('/admin/home')); ?>">
                    <?php echo e(config('app.name', 'AIB BANK')); ?>: Admin
                </a>
            </div>
            </center>
            <div class="collapse navbar-collapse" id="app-navbar-collapse">
                <!-- Left Side Of Navbar -->
                <ul class="nav navbar-nav">
                    &nbsp;
                </ul>

                <!-- Right Side Of Navbar -->
                <ul class="nav navbar-nav navbar-right">
                    <!-- Authentication Links -->
                    <?php if(Auth::guest()): ?>
                        <li><a href="<?php echo e(url('/admin/login')); ?>">Login</a></li>
                        <li><a href="<?php echo e(url('/admin/register')); ?>">Register</a></li>
                    <?php else: ?>
                        <li class="dropdown">
                            <a href="#" class="dropdown-toggle" data-toggle="dropdown" role="button" aria-expanded="false">
                                <?php echo e(Auth::user()->name); ?> <span class="caret"></span>
                            </a>

                            <ul class="dropdown-menu" role="menu">
                                <li>
                                    <a href="<?php echo e(url('/admin/logout')); ?>"
                                        onclick="event.preventDefault();
                                                 document.getElementById('logout-form').submit();">
                                        Logout
                                    </a>

                                    <form id="logout-form" action="<?php echo e(url('/admin/logout')); ?>" method="POST" style="display: none;">
                                        <?php echo e(csrf_field()); ?>

                                    </form>
                                </li>
                            </ul>
                        </li>
                    <?php endif; ?>
                </ul>
            </div>
        </div>
    </nav>

    <?php echo $__env->yieldContent('content'); ?>

  
</body>
  
 

     <script src="http://192.168.0.14:8080/compliance/public/js/jquery-1.12.4.js"></script>

    <script src="http://192.168.0.14:8080/compliance/public/js/bootstrap-datepicker.js"></script> 
     <script src="http://192.168.0.14:8080/compliance/public/js/jquery-ui.js"></script>

    <script src="http://192.168.0.14:8080/compliance/public/datatable/DataTables/js/jquery.dataTables.min.js"></script>
    <script src="http://192.168.0.14:8080/compliance/public/datatable/DataTables/js/dataTables.bootstrap.min.js"></script>
    <script src="http://192.168.0.14:8080/compliance/public/datatable/Buttons/js/dataTables.buttons.js"></script>
     <script src="http://192.168.0.14:8080/compliance/public/datatable/Buttons/js/dataTables.buttons.min.js"></script>
     <script src="http://192.168.0.14:8080/compliance/public/datatable/Buttons/js/buttons.colVis.min.js"></script>
      <script src="http://192.168.0.14:8080/compliance/public/datatable/Buttons/js/buttons.flash.js"></script>
      <script src="http://192.168.0.14:8080/compliance/public/datatable/Buttons/js/buttons.html5.js"></script>
      <script src="http://192.168.0.14:8080/compliance/public/datatable/Buttons/js/buttons.html5.min.js"></script>
      <script src="http://192.168.0.14:8080/compliance/public/datatable/Buttons/js/buttons.print.min.js"></script>

       <script type="text/javascript">
    $(document).ready(function() {
    $('#example').DataTable( {
        dom: 'Bfrtip',
        buttons: [
            'colvis', 'csv', 'excel'
        ]
        ,
        'lengthMenu': [[10, 25, 50, -1], [10, 25, 50, 'All']],
        'iDisplayLength': 250
    } );
} );
</script> 
     



<script>
  $( function() {
    $( "#datepicker,#datepicker1,#datepicker2" ).datepicker({
         changeMonth: true,
      changeYear: true
    });

  } );
  </script>




<script type="text/javascript">
    document.getElementById('test').addEventListener('change', function () {
    var style = this.value == 'YES' ? 'block' : 'none';
    document.getElementById('hidden_divc').style.display = style;
});

</script>

<script type="text/javascript">
    document.getElementById('testc').addEventListener('change', function () {
    var style = this.value == 'Incomplete' ? 'block' : 'none';
    document.getElementById('hidden_div').style.display = style;
});

</script>

<script type="text/javascript">
    document.getElementById('testc').addEventListener('change', function () {
    var style = this.value == 'Complete' ? 'block' : 'none';
    document.getElementById('hidden_div1').style.display = style;
});

</script>



</html>
