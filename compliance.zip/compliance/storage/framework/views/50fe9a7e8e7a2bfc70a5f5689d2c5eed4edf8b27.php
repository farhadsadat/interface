<?php $__env->startSection('content'); ?>
<center><h6>Users ADMIN</h6></center>
<hr>

<div class="container">
    <div class="row">
        <div class="col-md-12 col-md-offset-2">
        
        <a class="btn btn-primary" href="<?php echo e(url('/admin/register')); ?>" target="_blank">Register</a>    
       	<!--  <a class="btn btn-primary" onclick="location.href='<?php echo e(url('/admin/register')); ?>'">Register</a>	 -->	
            <table id="example" class="table table-striped table-bordered" cellspacing="0" width="100%">
           <thead>
            <tr style="background-color: #1f4a91; color: white;" >
            
                <th>ID</th>
                <th>User Name</th>
                <th>Email</th>
                <th>Password</th>
                <th>Register</th>
                <th>Edit</th>
                <th>Delete</th>
            </tr>
        </thead>
        
        <tbody>
        <?php $__currentLoopData = $ausers; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $auser): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <tr >
            
            <td><?php echo e($auser->id); ?></td>
            <td><?php echo e($auser->name); ?></td>
            <td><?php echo e($auser->email); ?></td>
            <td><?php echo e($auser->password); ?></td>
            <td><a class="btn btn-primary" href="<?php echo e(url('/admin/register')); ?>" target="_blank">Register</a></td>
            
             <td><a class="btn btn-primary" href="<?php echo e(route('editit',$auser->id)); ?>">Edit</a></td>
            <td>
            	 <?php echo Form::open(['method' => 'DELETE','route' => ['destroyit', $auser->id],'style'=>'display:inline']); ?>

            <?php echo Form::submit('Delete', ['class' => 'btn btn-danger']); ?>

            <?php echo Form::close(); ?>

            </td>

        </tr>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </tbody>     
    </table> 
        
        </div>

    </div>
</div>
<br>
<br>

<center><h6>Users Empolyee</h6></center>
<hr>

<div class="container">
    <div class="row">
        <div class="col-md-12 col-md-offset-2">
           <a class="btn btn-primary" href="<?php echo e(url('/employee/register')); ?>" target="_blank">Register</a> 

            <table id="example" class="table table-striped table-bordered" cellspacing="0" width="100%">
           <thead>
            <tr style="background-color: #1f4a91; color: white;" >
            
                <th>ID</th>
                <th>User Name</th>
                <th>Email</th>
                <th>Password</th>
                <th>Register</th>
                <th>Edit</th>
                <th>Delete</th>
            </tr>
        </thead>
        
        <tbody>
        <?php $__currentLoopData = $eusers; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $euser): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <tr >
            
            <td><?php echo e($euser->id); ?></td>
            <td><?php echo e($euser->name); ?></td>
            <td><?php echo e($euser->email); ?></td>
            <td><?php echo e($euser->password); ?></td>
            <td><a class="btn btn-primary" href="<?php echo e(url('/employee/register')); ?>" target="_blank">Register</a></td>
            <td><a class="btn btn-primary" href="<?php echo e(route('editem',$euser->id)); ?>">Edit</a></td>
            <td>
            	 <?php echo Form::open(['method' => 'DELETE','route' => ['destroyem', $euser->id],'style'=>'display:inline']); ?>

            <?php echo Form::submit('Delete', ['class' => 'btn btn-danger']); ?>

            <?php echo Form::close(); ?>

            </td>

            
             
            

        </tr>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </tbody>     
    </table> 
        
        </div>

    </div>
</div>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('admin.layout.auth', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>