<?php $__env->startSection('content'); ?>
<div class="container">
    <div class="row">
        <div class="col-md-8 col-md-offset-2">
            <div class="panel panel-default">
                <div class="panel-heading">Dashboard</div>

                <div class="panel-body">
                    You are logged in as Admin!
                </div>
            </div>
        </div>
    </div>
</div>

<div class="container">
    <div class="row">
        <div class="col-md-12 ">
            <table id="example" class="table table-striped table-bordered" cellspacing="0" width="100%">
           <thead>
            <tr style="color: green; ">
            <th>ID</th>
                <th>S.NO</th>
                <th>Date</th>
                <th>File Up No.</th>
                <th>Branch Name</th>
                <th>Customer Name</th>
                <th>Account Number</th>
                <th>Beneficiary Name</th>
                <th>Amount</th>
                <th>Currency</th>
                <th>Country</th>
                <th>ACCD Received</th>
                <th>Shiping Document Received</th>
                <th>Promisery Letter Received</th>
                <th>Sales Contract Received</th>
                <th>Lease Agreement Received</th>
                <th>Follow UP</th>
                <th>Due Date</th>
                <th>Extended Due Date</th>
                <th>Goods</th>
            </tr>
        </thead>
        <!-- <tfoot>
            <tr>
                <th>S.NO</th>
                <th>Date/th>
                <th>File Up No.</th>
                <th>Branch Name</th>
                <th>Customer Name</th>
                <th>Account Number</th>
                <th>Beneficiary Name</th>
                <th> Amount</th>
                <th>Currency</th>
                <th>Country</th>
                <th>ACCD Received</th>
                <th>Shiping Document Received</th>
                <th>Promisery Letter Received</th>
                <th>Sales Contract Received</th>
                <th>Lease Agreement Received</th>
                <th>Follow UP</th>
                <th>Due Date</th>
                <th>Extended Due Date</th>
                <th>Goods</th>
            </tr>
        </tfoot> -->

        <?php $__currentLoopData = $items; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $ho): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <tbody>
        <tr >
            <td><?php echo e(++$i); ?></td>
            <td><?php echo e($ho->sno); ?></td>
            <td><?php echo e($ho->sdate); ?></td>
            <td><?php echo e($ho->fileupno); ?></td>
            <td><?php echo e($ho->branchname); ?></td>
            <td><?php echo e($ho->cname); ?></td>
            <td><?php echo e($ho->acno); ?></td>
            <td><?php echo e($ho->benname); ?></td>
            <td><?php echo e($ho->amount); ?></td>
            <td><?php echo e($ho->currency); ?></td>
            <td><?php echo e($ho->country); ?></td>
            <td><?php echo e($ho->accdrec); ?></td>
            <td><?php echo e($ho->shdocrec); ?></td>
            <td><?php echo e($ho->pletterr); ?></td>
            <td><?php echo e($ho->scontactr); ?></td>
            <td><?php echo e($ho->largr); ?></td>
            <td><?php echo e($ho->followup); ?></td>
            <td><?php echo e($ho->duedate); ?></td>
            <td><?php echo e($ho->extduedate); ?></td>
            <td><?php echo e($ho->goods); ?></td>

        </tr>
        </tbody>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>


             </table> 
        
            <?php echo $items->render(); ?>


        </div>
    </div>
</div>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('admin.layout.auth', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>