<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1">

    <title>Compliance Interface</title>
    
   <link href="http://10.1.254.198/complianceTest/public/bootstrap/css/bootstrap.min.css" rel="stylesheet">
   <link rel="stylesheet" href="http://10.1.254.198/complianceTest/public/js/jquery-ui.css">

</head>
<body>
 
<div class="container">
    <?php echo $__env->yieldContent('content'); ?>
</div>


</body>

<script src="http://10.1.254.198/complianceTest/public/js/jquery-1.12.4.js"></script>
    <script src="http://10.1.254.198/complianceTest/public/js/bootstrap-datepicker.js"></script> 
    <script src="http://10.1.254.198/complianceTest/public/js/jquery-ui.js"></script>
 

<script>
  $( function() {
    $( "#datepicker,#datepicker1,#datepicker2" ).datepicker({
         changeMonth: true,
      changeYear: true
    });

  } );
  </script>



<script type="text/javascript">
    document.getElementById('test').addEventListener('change', function () {
    var style = this.value == 'YES' ? 'block' : 'none';
    document.getElementById('hidden_divc').style.display = style;
});

</script>

<script type="text/javascript">
    document.getElementById('testc').addEventListener('change', function () {
    var style = this.value == 'Incomplete' ? 'block' : 'none';
    document.getElementById('hidden_div').style.display = style;
});

</script>

<script type="text/javascript">
    document.getElementById('testc').addEventListener('change', function () {
    var style = this.value == 'Complete' ? 'block' : 'none';
    document.getElementById('hidden_div1').style.display = style;
});

</script>



</html>