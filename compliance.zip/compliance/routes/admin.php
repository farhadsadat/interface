<?php
use App\Homes;
use App\Admin;
use App\Employee;

Route::get('/table', function () {
    $users[] = Auth::user();
    $users[] = Auth::guard()->user();
    $users[] = Auth::guard('admin')->user();

    //dd($users);
 $items = Homes::where('complete','=','Incomplete' )->orWhere('complete','=',NULL )->orderBy('id', 'ASC')->take(1000000)->get();
    return view('admin.table',compact('items'));
});

Route::get('/home', function () {
    $users[] = Auth::user();
    $users[] = Auth::guard()->user();
    $users[] = Auth::guard('admin')->user();

    //dd($users);

    return view('admin.home');
})->name('home');


Route::get('/users', function () {
    $users[] = Auth::user();
    $users[] = Auth::guard()->user();
    $users[] = Auth::guard('admin')->user();

    //dd($users);
$ausers = Admin::all();
$eusers = Employee::all();
    return view('admin.users',compact('ausers','eusers'));
});


