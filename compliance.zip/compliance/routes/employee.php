<?php
use App\Homes;


Route::get('/home', function () {
    $users[] = Auth::user();
    $users[] = Auth::guard()->user();
    $users[] = Auth::guard('employee')->user();

    //dd($users);

    return view('employee.home');
})->name('home');

Route::get('/table', function () {
    $users[] = Auth::user();
    $users[] = Auth::guard()->user();
    $users[] = Auth::guard('employee')->user();

    //dd($users);
$items = Homes::where('complete','=','Incomplete' )->orWhere('complete','=',NULL )
               ->orderBy('id', 'desc')
               ->take(10000000)
               ->get();
    return view('employee.table',compact('items'));
});

