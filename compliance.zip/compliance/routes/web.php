<?php

/*
|--------------------------------------------------------------------------
| Web Routes
|--------------------------------------------------------------------------
|
| Here is where you can register web routes for your application. These
| routes are loaded by the RouteServiceProvider within a group which
| contains the "web" middleware group. Now create something great!
|
*/



Route::get('/','PageController@index');
Route::get('/complete','PageController@complete');
Route::get('/search','PageController@searchc');

Route::group(['prefix' => 'admin'], function () {

  Route::get('/users','HomesController@adminusers');
  Route::get('/complete','HomesController@complete');
  Route::resource('/table','HomesController');
  Route::get('/login',['as' => 'login', 'uses' => 'AdminAuth\LoginController@showLoginForm']);

  Route::post('/login',['as' => 'login', 'uses' => 'AdminAuth\LoginController@login']);

  Route::post('/logout',['as' => 'logout', 'uses' => 'AdminAuth\LoginController@logout']);

  
  

  Route::get('/register', ['as' => 'register', 'uses' =>'AdminAuth\RegisterController@showRegistrationForm']);

  Route::post('/register', ['as' => 'register', 'uses' =>'AdminAuth\RegisterController@register']);

  Route::post('/password/email', 'AdminAuth\ForgotPasswordController@sendResetLinkEmail');
  Route::post('/password/reset', 'AdminAuth\ResetPasswordController@reset');
  Route::get('/password/reset', 'AdminAuth\ForgotPasswordController@showLinkRequestForm');
  Route::get('/password/reset/{token}', 'AdminAuth\ResetPasswordController@showResetForm');


  Route::get('/admin/editit/{id}', array("as" => "editit", 'uses' => 'HomesController@editit'));

  Route::delete('/admin/destroyit/{id}', array("as" => "destroyit", 'uses' => 'HomesController@destroyit'));


  Route::match(['put', 'patch'],'/admin/updateit/{id}',array("as" => "updateit", 'uses' => 'HomesController@updateit'));

  Route::get('/admin/editem/{id}', array("as" => "editem", 'uses' => 'HomesController@editem'));

  Route::delete('/admin/destroyem/{id}', array("as" => "destroyem", 'uses' => 'HomesController@destroyem'));


  Route::match(['put', 'patch'],'/admin/updateem/{id}',array("as" => "updateem", 'uses' => 'HomesController@updateem'));




});

Route::group(['prefix' => 'employee'], function () {
  Route::resource('/table','EmployeeController');
  Route::get('/complete','EmployeeController@complete');
  Route::get('/login', 'EmployeeAuth\LoginController@showLoginForm');
  Route::post('/login', 'EmployeeAuth\LoginController@login');
  Route::post('/logout', 'EmployeeAuth\LoginController@logout');

  // Route::get('/register',  ['as' => 'register', 'uses' =>'EmployeeAuth\RegisterController@showRegistrationForm']);
  // Route::post('/register', ['as' => 'register', 'uses' =>'EmployeeAuth\RegisterController@register']);

   Route::get('/register', 'EmployeeAuth\RegisterController@showRegistrationForm');
   Route::post('/register', 'EmployeeAuth\RegisterController@register');

  Route::post('/password/email', 'EmployeeAuth\ForgotPasswordController@sendResetLinkEmail');
  Route::post('/password/reset', 'EmployeeAuth\ResetPasswordController@reset');
  Route::get('/password/reset', 'EmployeeAuth\ForgotPasswordController@showLinkRequestForm');
  Route::get('/password/reset/{token}', 'EmployeeAuth\ResetPasswordController@showResetForm');



});

