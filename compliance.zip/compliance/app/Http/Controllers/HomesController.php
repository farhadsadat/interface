<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use Illuminate\Support\Facades\Hash;

use DB;
use App\Homes;
use Auth;
use App\Admin;
use App\Employee;
class HomesController extends Controller
{
    /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function index()
    {
       
        $items = Homes::where('complete','=','Incomplete' )->orWhere('complete','=',NULL )->orderBy('id', 'desc')->take(10000000000)->get();

        return view('admin.table',compact('items'));
         
    }

    /**
     * Show the form for creating a new resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function create()
    {
       $users = DB::table('admins')->get();
       

       return view('admin.create',compact('users'));
    }

    /**
     * Store a newly created resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\Response
     */
    public function store(Request $request)
    {

         $this->validate($request, [
            'sdate' => 'required|nullable|date',
            'fileupno' => 'required|max:255',
            'branchname' => 'required',
            'cname' => 'required',
            'acno' => 'required',
            'benname' => 'required',
            'goods' => 'required',
            'invoice' => 'required',
            'amount' => 'required',
            'currency' => 'required',
            'country' => 'required',
            'accdrec' => 'required',
            'shdocrec' => 'required',
            'pletterr' => 'required',
            'scontactr' => 'required',
            'largr' => 'required',
            'duedate' => 'required|nullable|date',
            'goods' => 'required',
        ]
        ,
        [
            'sdate.required' => 'Please provide correct date for Date Filed',
            'fileupno.required' => 'Please provide correct fileup Number',
            'branchname.required' => 'Please select a Branch Name',
            'cname.required' => 'Please provide correct Customer Name',
            'acno.required' => 'Please provide correct Account Number',
            'benname.required' => 'Please provide correct Ben Name',
            'goods.required' => 'Please provide correct descreption of Goods',
            'invoice.required' => 'Please provide correct invoice',
            'amount.required' => 'Please provide correct amount',
            'currency.required' => 'Please provide correct Currency',
            'country.required' => 'Please select a Country',
            'accdrec.required' => 'Please select a ACCD Recieved',
            'shdocrec.required' => 'Please select a Shipping Documents Recieved',
            'pletterr.required' => 'Please select a Promissory Letter Recieved',
            'scontactr.required' => 'Please select a Contract Recieved',
            'largr.required' => 'Please select a Lease Agreement Recieved',
            'duedate.required' => 'Please provide correct Due Date',
        ]
        );
        
        

        Homes::create($request->all());
        return redirect()->route('admin.home')
                        ->with('success','Item created successfully');
    }

    /**
     * Display the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function show($id)
    {
         $home = Homes::find($id);
        return view('admin.show',compact('home'));
    }

    /**
     * Show the form for editing the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function edit($id)
    {
        $items = Homes::find($id);
        return view('admin.edit',compact('items'));
    }

    /**
     * Update the specified resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function update(Request $request, $id)
    {
        $this->validate($request, [
            'sdate' => 'required|nullable|date',
            'fileupno' => 'required|max:255',
            'branchname' => 'required',
            'cname' => 'required',
            'acno' => 'required',
            'benname' => 'required',
            'amount' => 'required',
            'currency' => 'required',
            'country' => 'required',
            'accdrec' => 'required',
            'shdocrec' => 'required',
            'pletterr' => 'required',
            'scontactr' => 'required',
            'largr' => 'required',

            'duedate' => 'required|nullable|date',
          
            'goods' => 'required',
            'invoice' => 'required',
            
        ],
         [
            'sdate.required' => 'Please provide correct date for Date Filed',
            'fileupno.required' => 'Please provide correct fileup Number',
            'branchname.required' => 'Please select a Branch Name',
            'cname.required' => 'Please provide correct Customer Name',
            'acno.required' => 'Please provide correct Account Number',
            'benname.required' => 'Please provide correct Ben Name',
            'goods.required' => 'Please provide correct descreption of Goods',
            'invoice.required' => 'Please provide correct invoice',
            'amount.required' => 'Please provide correct amount',
            'currency.required' => 'Please provide correct Currency',
            'country.required' => 'Please select a Country',
            'accdrec.required' => 'Please select a ACCD Recieved',
            'shdocrec.required' => 'Please select a Shipping Documents Recieved',
            'pletterr.required' => 'Please select a Promissory Letter Recieved',
            'scontactr.required' => 'Please select a Contract Recieved',
            'largr.required' => 'Please select a Lease Agreement Recieved',
            'duedate.required' => 'Please provide correct Due Date',
        ]

        );


        Homes::find($id)->update($request->all());
        return redirect()->route('admin.home')
                        ->with('success','Item updated successfully');
    }

    /**
     * Remove the specified resource from storage.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function destroy($id)
    {
        Homes::find($id)->delete();
        return redirect()->route('admin.home')
                        ->with('success','Item deleted successfully');
    }

    public function adminusers()
    {    
        $eusers = Employee::orderBy('id', 'desc')
               ->take(10000)
               ->get();
         $ausers = Admin::orderBy('id', 'desc')
               ->take(10000)
               ->get();
        return view('admin.users',compact('ausers','eusers'));
    }



     // ADMIN
    public function editit($id)
    {
       
       $users = Admin::find($id);

        return view('admin.admin.editit',compact('users'));


    }

    public function destroyit($id)
    {
         Admin::find($id)->delete();
            return redirect()->route('admin.home')
                        ->with('success','Item deleted successfully');
                        
    }

    public function updateit(Request $request, $id)
    {
        $this->validate($request, [
            'name' => 'required',
            'password' => 'required',
            'email' => 'required',          
        ]);

        // Itmanager::find($id)->update($request->all());

    $it = Admin::find($id);
    $it->name= $request['name'];  
    $it->password= Hash::make($request->password);
    $it->email= $request['email'];
    $it->created_at= $request['created_at'];

    $it->save();

        return redirect()->route('admin.home')
                        ->with('success','Form updated successfully');
    }

    //End of Admin


      // EMPLOYEE
    public function editem($id)
    {
       
       $users = Employee::find($id);

        return view('admin.employee.editem',compact('users'));


    }

    public function destroyem($id)
    {
         Employee::find($id)->delete();
            return redirect()->route('admin.home')
                        ->with('success','Item deleted successfully');
                        
    }

    public function updateem(Request $request, $id)
    {
        $this->validate($request, [
            'name' => 'required',
            'password' => 'required',
            'email' => 'required',          
        ]);

        // EMPLOYEE::find($id)->update($request->all());

    $it = Employee::find($id);
    $it->name= $request['name'];  
    $it->password= Hash::make($request->password);
    $it->email= $request['email'];
    $it->created_at= $request['created_at'];

    $it->save();

        return redirect()->route('admin.home')
                        ->with('success','Form updated successfully');
    }

    //End of EMPLOYEE

    public function complete()
    {
         $items = Homes::where('complete','=','Complete' )
               ->orderBy('id', 'desc')
               ->take(10000000000)
               ->get();

        return view('admin.complete',compact('items'));
    }


}
