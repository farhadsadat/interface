<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;

use App\Homes;
use DB;

class PageController extends Controller
{
   
   public function index(Request $request)
    {
        
        $items = Homes::where('complete','=','Incomplete' )->orWhere('complete','=',NULL )
               ->orderBy('id', 'desc')
               ->take(1000000000000)
               ->get();
        $items= Homes::paginate(1000);
        return view('index',compact('items'))->with('i', ($request->input('items', 1) - 1) * 1000);
         
    }

     public function searchc(Request $request)
    {
         $fileupno = $request->input('fileupno');
         $branchname = $request->input('branchname');

         $result = DB::table('homes')
         ->select(DB::raw("*"))
            ->where('fileupno', '=', $fileupno)
            ->where('branchname', '=', $branchname)
            ->get();
            return view('search',compact('result','items'));
        // $items = Homes::where('complete','=','Incomplete' )->orWhere('complete','=',NULL )
        //        ->orderBy('id', 'desc')
        //        ->take(1000000000000)
        //        ->get()
        //        ->where('fileupno','LIKE','%'.$fileupno.'%' or 'branchname','LIKE','%'.$branchname.'%');
        // $items= Homes::paginate(1000000000000);
        // return view('search',compact('items'))->with('i', ($request->input('items', 1) - 1) * 1000000000000);

         
    }


    public function complete()
    {
    	 $items = Homes::where('complete','=','Complete' )
               ->orderBy('id', 'desc')
               ->take(10000000000)
               ->get();

        return view('complete',compact('items'));
    }
}
