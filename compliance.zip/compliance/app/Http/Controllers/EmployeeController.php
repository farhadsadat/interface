<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\Homes;
use App\Admin;
use App\Employee;
use DB;
class EmployeeController extends Controller
{
    /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function index()
    {
        $items = Homes::where('complete','=','Incomplete' )->orWhere('complete','=',NULL )
               ->orderBy('id', 'desc')
               ->take(10000000000)
               ->get();

        return view('employee.table',compact('items'));
    }

    /**
     * Show the form for creating a new resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function create()
    {
        $usersem = DB::table('employees')->take(1)->get();

        return view('employee.create',compact('usersem'));
    }

    /**
     * Store a newly created resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\Response
     */
    public function store(Request $request)
    {
         $this->validate($request, [
            'sdate' => 'required|nullable|date',
            'fileupno' => 'required|max:255',
            'branchname' => 'required',
            'cname' => 'required|max:255',
            'acno' => 'required',
            'benname' => 'required',
            'goods' => 'required',
            'amount' => 'required',
            'currency' => 'required',
            'country' => 'required',
            'accdrec' => 'required',
            'shdocrec' => 'required',
            'pletterr' => 'required',
            'scontactr' => 'required',
            'largr' => 'required',
            'duedate' => 'required|nullable|date',
            'goods' => 'required',
        ]
        ,
        [
            'sdate.required' => 'Please provide correct date for Date Filed',
            'fileupno.required' => 'Please provide correct fileup Number',
            'branchname.required' => 'Please select a Branch Name',
            'cname.required' => 'Please provide correct Customer Name',
            'acno.required' => 'Please provide correct Account Number',
            'benname.required' => 'Please provide correct Ben Name',
            'goods.required' => 'Please provide correct descreption of Goods',
            'amount.required' => 'Please provide correct amount',
            'currency.required' => 'Please provide correct Currency',
            'country.required' => 'Please select a Country',
            'accdrec.required' => 'Please select a ACCD Recieved',
            'shdocrec.required' => 'Please select a Shipping Documents Recieved',
            'pletterr.required' => 'Please select a Promissory Letter Recieved',
            'scontactr.required' => 'Please select a Contract Recieved',
            'largr.required' => 'Please select a Lease Agreement Recieved',
            'duedate.required' => 'Please provide correct Due Date',
        ]
        );
        
        

        Homes::create($request->all());
        return redirect()->route('employee.home')
                        ->with('success','Item created successfully');
    }

    /**
     * Display the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function show($id)
    {
        $home = Homes::find($id);
        return view('employee.show',compact('home'));
    }

    /**
     * Show the form for editing the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function edit($id)
    {
        $items = Homes::find($id);
        return view('employee.edit',compact('items'));
    }

    /**
     * Update the specified resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function update(Request $request, $id)
    {
        $this->validate($request, [
            'sdate' => 'required|nullable|date',
            'fileupno' => 'required|max:255',
            'branchname' => 'required',
            'cname' => 'required|max:255',
            'acno' => 'required|numeric',
            'benname' => 'required',
            'amount' => 'required',
            'currency' => 'required',
            'country' => 'required',
            'accdrec' => 'required',
            'shdocrec' => 'required',
            'pletterr' => 'required',
            'scontactr' => 'required',
            'largr' => 'required',

            'duedate' => 'required|nullable|date',
          
            'goods' => 'required',
            
            
        ],
         [
            'sdate.required' => 'Please provide correct date for Date Filed',
            'fileupno.required' => 'Please provide correct fileup Number',
            'branchname.required' => 'Please select a Branch Name',
            'cname.required' => 'Please provide correct Customer Name',
            'acno.required' => 'Please provide correct Account Number',
            'benname.required' => 'Please provide correct Ben Name',
            'goods.required' => 'Please provide correct descreption of Goods',
            'amount.required' => 'Please provide correct amount',
            'currency.required' => 'Please provide correct Currency',
            'country.required' => 'Please select a Country',
            'accdrec.required' => 'Please select a ACCD Recieved',
            'shdocrec.required' => 'Please select a Shipping Documents Recieved',
            'pletterr.required' => 'Please select a Promissory Letter Recieved',
            'scontactr.required' => 'Please select a Contract Recieved',
            'largr.required' => 'Please select a Lease Agreement Recieved',
            'duedate.required' => 'Please provide correct Due Date',
        ]


        );


        Homes::find($id)->update($request->all());
        return redirect()->route('employee.home')
                        ->with('success','Item updated successfully');
    }

    /**
     * Remove the specified resource from storage.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function destroy($id)
    {
        Homes::find($id)->delete();
        return redirect()->route('employee.home')
                        ->with('success','Item deleted successfully');
    }
     public function complete()
    {
         $items = Homes::where('complete','=','Complete' )
               ->orderBy('id', 'desc')
               ->take(10000000000)
               ->get();

        return view('employee.complete',compact('items'));
    }
}
