<?php

namespace App;

use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\SoftDeletes;

class Homes extends Model
{
	 use SoftDeletes;
	 protected $dates = ['deleted_at'];
	 protected $table = 'homes';
	 protected $primaryKey = 'id';
	 public $timestamps = false;
    //
	 protected $fillable = [
	 'employees_name',
	 'fileupno',
	 'sdate',
	 'branchname',
	 'cname',
	 'acno',
	 'benname',
	 'goods',
	 'invoice',
	 'amount',
	 'currency',
	 'country',
	 'accdrec',
	 'shdocrec',
	 'pletterr',
	 'scontactr',
	 'largr',
	 'duedate',
	 'extduedate',
	 'extenddatedate',
	 'extreason',
	 'complete',
	 'cfileupno',
	 'incocomment',

	 ];

	  
}
