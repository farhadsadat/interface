<?php

use Illuminate\Support\Facades\Schema;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Database\Migrations\Migration;

class CreateHomesTable extends Migration
{
    /**
     * Run the migrations.
     *
     * @return void
     */
    public function up()
    {   
        Schema::create('homes', function (Blueprint $table) {
        $table->increments('id');
        
        $table->string('sdate');
        $table->string('fileupno');
        $table->string('branchname');
        $table->string('cname');
        $table->string('acno');
        $table->string('benname');
        $table->string('amount');
        $table->string('currency');
        $table->string('country');
        $table->string('accdrec');
        $table->string('shdocrec');
        $table->string('pletterr');
        $table->string('scontactr');
        $table->string('largr');
        $table->string('duedate');
        $table->string('extduedate');
        $table->string('goods');
        $table->string('invoice');
        $table->string('extenddatedate')->nullable()->default(null);
        $table->string('extreason')->nullable()->default(null);
        $table->string('complete')->nullable()->default(null);
        $table->string('cfileupno')->nullable()->default(null);
        $table->string('incomplete')->nullable()->default(null);
        $table->string('incocomment')->nullable()->default(null);
        $table->string('employees_name');

        $table->softDeletes();
        });
    }

    /**
     * Reverse the migrations.
     *
     * @return void
     */
    public function down()
    {
        Schema::dropIfExists('homes');
    }
}
